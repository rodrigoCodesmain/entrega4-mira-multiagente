# MIRA CU-2 — API de Elegibilidad de Reprocesamiento

Prototipo mínimo en Python + FastAPI + `pytest` para evaluar de forma determinista y en modo de solo lectura si un caso de MIRA CU-2 es elegible para reprocesamiento conforme a `specs/01-requisitos.md`, `MAN-INC` v2 y `CAT-ERR` v2.

## Instalación de dependencias

Con `uv` (Python 3.12):

```bash
uv sync --python 3.12
```

Alternativamente, con `pip` en un entorno virtual Python >= 3.12:

```bash
python3 -m venv .venv
. .venv/bin/activate
pip install -e ".[dev]"
```

## Ejecución de pruebas e integridad del kit

Ejecutar la suite automatizada de `pytest` junto con la verificación de checksums SHA-256 del kit (sin escribir bytecode ni cachés):

```bash
./.agents/skills/ejecucion-pruebas/scripts/run_tests.sh
```

Verificar también la integridad del kit y la estructura de la matriz de trazabilidad:

```bash
python3 .agents/skills/trazabilidad/scripts/verificar_trazabilidad.py --check-kit --matrix specs/03-trazabilidad.md
```

## Levantar la API

Iniciar el servidor local con `uvicorn` (leyendo `kit/CU-2_soporte_operacion/datos/CU-2_datos.xlsx` en modo solo lectura):

```bash
PYTHONDONTWRITEBYTECODE=1 .venv/bin/uvicorn mira_cu2.api:app --host 127.0.0.1 --port 8000
```

## Ejemplo de consulta

```bash
curl -sS -X POST http://127.0.0.1:8000/elegibilidad \
  -H "Content-Type: application/json" \
  -d '{"caso_id": "C-032", "usuario_id": "U-S1"}'
```
