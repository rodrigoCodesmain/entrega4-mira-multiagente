"""Paquete principal del servicio MIRA CU-2 de elegibilidad de reprocesamiento."""

from mira_cu2.api import app, create_app

__all__ = ["app", "create_app"]
