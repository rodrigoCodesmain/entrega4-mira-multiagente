"""Aplicación FastAPI mínima para evaluación de elegibilidad en MIRA CU-2."""

from __future__ import annotations

import os

from fastapi import FastAPI, HTTPException

from mira_cu2.models import (
    CasoNoEncontradoError,
    EvaluacionRequest,
    EvaluacionResponse,
    UsuarioNoAutorizadoError,
)
from mira_cu2.repository import RepositorioDatos, RepositorioExcel
from mira_cu2.rules import evaluar_solicitud


def create_app(repositorio: RepositorioDatos | None = None) -> FastAPI:
    """Construye la instancia FastAPI inyectando un repositorio de solo lectura."""
    repo = repositorio if repositorio is not None else RepositorioExcel(os.environ.get("MIRA_CU2_EXCEL_PATH"))
    api = FastAPI(
        title="MIRA CU-2 · API de Elegibilidad de Reprocesamiento",
        version="0.1.0",
    )

    @api.post("/elegibilidad", response_model=EvaluacionResponse)
    def evaluar_elegibilidad(payload: EvaluacionRequest) -> EvaluacionResponse:
        try:
            return evaluar_solicitud(
                caso_id=payload.caso_id,
                usuario_id=payload.usuario_id,
                repositorio=repo,
            )
        except UsuarioNoAutorizadoError as exc:
            raise HTTPException(status_code=403, detail=str(exc)) from exc
        except CasoNoEncontradoError as exc:
            raise HTTPException(status_code=404, detail=str(exc)) from exc

    return api


app = create_app()
