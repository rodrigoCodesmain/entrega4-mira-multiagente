"""Repositorios de solo lectura para usuarios, servicios y casos de MIRA CU-2."""

from __future__ import annotations

from collections.abc import Iterable, Mapping
from pathlib import Path
from typing import Protocol, TypeVar

import openpyxl

from mira_cu2.models import Caso, Servicio, Usuario

DEFAULT_EXCEL_PATH = (
    Path(__file__).resolve().parents[2]
    / "kit"
    / "CU-2_soporte_operacion"
    / "datos"
    / "CU-2_datos.xlsx"
)

_T = TypeVar("_T")


def _parse_si_no(valor: object) -> bool:
    """Convierte valores 'sí'/'si' y 'no' del Excel a booleano estricto."""
    normalizado = str(valor).strip().lower()
    if normalizado in {"sí", "si"}:
        return True
    if normalizado == "no":
        return False
    raise ValueError(f"Valor booleano 'sí'/'no' inválido: {valor!r}")


def _indexar_por_id(
    elementos: Iterable[_T] | Mapping[str, _T],
    campo_id: str,
) -> dict[str, _T]:
    """Construye un diccionario indexado por clave primaria."""
    if isinstance(elementos, Mapping):
        items = elementos.values()
    else:
        items = elementos
    return {getattr(item, campo_id): item for item in items}


def _leer_filas_hoja(ws: object) -> list[dict[str, object]]:
    """Lee una hoja de openpyxl mapeando columnas según la fila 1 de encabezados."""
    rows_iter = ws.iter_rows(values_only=True)  # type: ignore[attr-defined]
    try:
        headers_raw = next(rows_iter)
    except StopIteration:
        return []

    headers = [str(col).strip() if col is not None else "" for col in headers_raw]
    registros: list[dict[str, object]] = []
    for row in rows_iter:
        if all(cell is None or str(cell).strip() == "" for cell in row):
            continue
        registro: dict[str, object] = {}
        for idx, header in enumerate(headers):
            if not header:
                continue
            registro[header] = row[idx] if idx < len(row) else None
        registros.append(registro)
    return registros


class RepositorioDatos(Protocol):
    """Puerto de solo lectura para consultar entidades operativas de MIRA CU-2."""

    def obtener_usuario(self, usuario_id: str) -> Usuario | None:
        """Retorna el usuario por identificador o None si no existe."""

    def obtener_caso(self, caso_id: str) -> Caso | None:
        """Retorna el caso por identificador o None si no existe."""

    def obtener_servicio(self, servicio_id: str) -> Servicio | None:
        """Retorna el servicio por identificador o None si no existe."""


class RepositorioMemoria:
    """Repositorio en memoria indexado por ID, sin acceso a registro_tecnico."""

    def __init__(
        self,
        usuarios: Iterable[Usuario] | Mapping[str, Usuario] = (),
        servicios: Iterable[Servicio] | Mapping[str, Servicio] = (),
        casos: Iterable[Caso] | Mapping[str, Caso] = (),
    ) -> None:
        self._usuarios = _indexar_por_id(usuarios, "usuario_id")
        self._servicios = _indexar_por_id(servicios, "servicio_id")
        self._casos = _indexar_por_id(casos, "caso_id")

    def obtener_usuario(self, usuario_id: str) -> Usuario | None:
        return self._usuarios.get(usuario_id)

    def obtener_caso(self, caso_id: str) -> Caso | None:
        return self._casos.get(caso_id)

    def obtener_servicio(self, servicio_id: str) -> Servicio | None:
        return self._servicios.get(servicio_id)


class RepositorioExcel(RepositorioMemoria):
    """Carga usuarios, servicios y casos en modo solo lectura desde CU-2_datos.xlsx.

    Por requisito de seguridad (REQ-17), nunca abre ni lee la hoja 'registro_tecnico'.
    """

    def __init__(self, excel_path: Path | str | None = None) -> None:
        path = Path(excel_path) if excel_path is not None else DEFAULT_EXCEL_PATH
        wb = openpyxl.load_workbook(path, read_only=True, data_only=True)
        try:
            usuarios = [
                Usuario(
                    usuario_id=str(fila["usuario_id"]).strip(),
                    nombre=str(fila["nombre"]).strip(),
                    rol=str(fila["rol"]).strip(),
                    organizacion=str(fila["organizacion"]).strip(),
                )
                for fila in _leer_filas_hoja(wb["usuarios"])
            ]
            servicios = [
                Servicio(
                    servicio_id=str(fila["servicio_id"]).strip(),
                    nombre=str(fila["nombre"]).strip(),
                    tipo=str(fila["tipo"]).strip(),
                    estado=str(fila["estado"]).strip(),
                )
                for fila in _leer_filas_hoja(wb["servicios"])
            ]
            casos = [
                Caso(
                    caso_id=str(fila["caso_id"]).strip(),
                    org_id=str(fila["org_id"]).strip(),
                    estado=str(fila["estado"]).strip(),
                    codigo_error=str(fila["codigo_error"]).strip(),
                    modulo=str(fila["modulo"]).strip(),
                    servicio_dependiente=str(fila["servicio_dependiente"]).strip(),
                    reprocesos_realizados=int(fila["reprocesos_realizados"]),  # type: ignore[arg-type]
                    tiene_decision_final=_parse_si_no(fila["tiene_decision_final"]),
                )
                for fila in _leer_filas_hoja(wb["casos"])
            ]
        finally:
            wb.close()

        super().__init__(usuarios=usuarios, servicios=servicios, casos=casos)
