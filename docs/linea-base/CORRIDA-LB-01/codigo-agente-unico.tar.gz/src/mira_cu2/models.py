"""Modelos de dominio, excepciones y esquemas HTTP para MIRA CU-2."""

from __future__ import annotations

from dataclasses import dataclass
from pydantic import BaseModel, ConfigDict, StrictStr, field_validator


@dataclass(frozen=True, slots=True)
class Usuario:
    """Actor interno de DPRIME usado para validación simulada de rol."""

    usuario_id: str
    nombre: str
    rol: str
    organizacion: str


@dataclass(frozen=True, slots=True)
class Servicio:
    """Estado operativo de un servicio interno o externo del que depende MIRA."""

    servicio_id: str
    nombre: str
    tipo: str
    estado: str


@dataclass(frozen=True, slots=True)
class Caso:
    """Metadatos operativos de un caso evaluable en modo de solo lectura."""

    caso_id: str
    org_id: str
    estado: str
    codigo_error: str
    modulo: str
    servicio_dependiente: str
    reprocesos_realizados: int
    tiene_decision_final: bool


class UsuarioNoAutorizadoError(Exception):
    """Error cuando el usuario no existe o su rol no está habilitado."""


class CasoNoEncontradoError(Exception):
    """Error cuando el caso solicitado no existe para un usuario autorizado."""


class EvaluacionRequest(BaseModel):
    """Contrato de entrada para consultar elegibilidad de reprocesamiento."""

    model_config = ConfigDict(extra="forbid")

    caso_id: StrictStr
    usuario_id: StrictStr

    @field_validator("caso_id", "usuario_id", mode="after")
    @classmethod
    def _no_vacio(cls, value: str) -> str:
        stripped = value.strip()
        if not stripped:
            raise ValueError("El campo no puede estar vacío ni contener solo espacios.")
        return stripped


class EvaluacionResponse(BaseModel):
    """Contrato mínimo de 4 campos para evaluaciones válidas (HTTP 200 OK)."""

    model_config = ConfigDict(extra="forbid")

    puede_reprocesar: bool
    motivos: list[str]
    accion_recomendada: str
    referencias_normativas: list[str]
