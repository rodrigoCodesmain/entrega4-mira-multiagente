"""Motor determinista de elegibilidad de reprocesamiento según MAN-INC v2 y CAT-ERR v2."""

from __future__ import annotations

from dataclasses import dataclass

from mira_cu2.models import (
    Caso,
    CasoNoEncontradoError,
    EvaluacionResponse,
    Servicio,
    UsuarioNoAutorizadoError,
)
from mira_cu2.repository import RepositorioDatos

ROLES_AUTORIZADOS = frozenset({"soporte_n1", "soporte_n2", "ingenieria"})
ESTADOS_ELEGIBLES = frozenset({"error", "detenido"})
LIMITE_GENERAL_REPROCESOS = 3
LIMITE_E512_REPROCESOS = 1
SERVICIO_E207 = "SRV-MOD"
REF_MAN_INC = "MAN-INC v2 §4"


@dataclass(frozen=True, slots=True)
class ReglaCodigoError:
    """Definición normativa vigente de un código de error en CAT-ERR v2 §1."""

    codigo: str
    descripcion: str
    reprocesable: bool
    limite_reprocesos: int | None
    accion_bloqueado: str
    accion_elegible: str | None = None

    @property
    def referencia(self) -> str:
        return f"CAT-ERR v2 §1 ({self.codigo})"


CATALOGO_ERRORES_V2: dict[str, ReglaCodigoError] = {
    "E-101": ReglaCodigoError(
        codigo="E-101",
        descripcion="Evidencia ilegible",
        reprocesable=False,
        limite_reprocesos=None,
        accion_bloqueado="Solicitar el reenvío de la evidencia; no reprocesar.",
    ),
    "E-102": ReglaCodigoError(
        codigo="E-102",
        descripcion="Formato de archivo no soportado",
        reprocesable=False,
        limite_reprocesos=None,
        accion_bloqueado="Informar a la organización los formatos aceptados; no reprocesar.",
    ),
    "E-207": ReglaCodigoError(
        codigo="E-207",
        descripcion="Tiempo de espera agotado con el proveedor de modelos",
        reprocesable=True,
        limite_reprocesos=LIMITE_GENERAL_REPROCESOS,
        accion_bloqueado="No reprocesar; el caso permanece en cola y se reintenta automáticamente.",
        accion_elegible="Proceder con el reprocesamiento.",
    ),
    "E-208": ReglaCodigoError(
        codigo="E-208",
        descripcion="Cuota del proveedor de modelos agotada",
        reprocesable=False,
        limite_reprocesos=None,
        accion_bloqueado="Registrar incidente S2 y escalar a Ingeniería; no reprocesar.",
    ),
    "E-305": ReglaCodigoError(
        codigo="E-305",
        descripcion="Módulo de análisis no disponible",
        reprocesable=True,
        limite_reprocesos=LIMITE_GENERAL_REPROCESOS,
        accion_bloqueado="No reprocesar; esperar a que el servicio dependiente vuelva a estar operativo.",
        accion_elegible="Proceder con el reprocesamiento.",
    ),
    "E-311": ReglaCodigoError(
        codigo="E-311",
        descripcion="La versión de módulo fijada en el flujo no está disponible",
        reprocesable=False,
        limite_reprocesos=None,
        accion_bloqueado="Escalar a Ingeniería; no reprocesar con otra versión sin autorización de la organización.",
    ),
    "E-410": ReglaCodigoError(
        codigo="E-410",
        descripcion="Límite de llamadas por minuto superado",
        reprocesable=False,
        limite_reprocesos=None,
        accion_bloqueado=(
            "No reprocesar; el caso se encola y se procesa cuando hay capacidad "
            "(sin acción de soporte salvo cola > 6 horas)."
        ),
    ),
    "E-512": ReglaCodigoError(
        codigo="E-512",
        descripcion="Error interno de la plataforma",
        reprocesable=True,
        limite_reprocesos=LIMITE_E512_REPROCESOS,
        accion_bloqueado="No reprocesar; escalar a Ingeniería.",
        accion_elegible="Reprocesar una vez; si vuelve a fallar, escalar a Ingeniería.",
    ),
}


def _agregar_unico(destino: list[str], valor: str) -> None:
    if valor not in destino:
        destino.append(valor)


def _seleccionar_accion_bloqueada(
    caso: Caso,
    regla_codigo: ReglaCodigoError | None,
    inconsistencia_tecnica: bool,
    limite_alcanzado: bool,
    servicio_no_operativo: bool,
) -> str:
    """Determina la acción recomendada vigente según orden determinista de prioridad."""
    if caso.tiene_decision_final:
        return "No reprocesar: el caso ya tiene una decisión final."

    if inconsistencia_tecnica or regla_codigo is None:
        return "No reprocesar; escalar a Ingeniería por inconsistencia en los datos técnicos del caso."

    if not regla_codigo.reprocesable:
        return regla_codigo.accion_bloqueado

    if limite_alcanzado:
        if caso.codigo_error == "E-512":
            return regla_codigo.accion_bloqueado
        return "No reprocesar; escalar a Ingeniería como incidente S3 sin volver a intentar."

    if servicio_no_operativo:
        if caso.codigo_error == "E-207":
            return regla_codigo.accion_bloqueado
        return "No reprocesar; esperar a que el servicio dependiente vuelva a estar operativo."

    return "No reprocesar; solo se reprocesan casos en estado 'error' o 'detenido'."


def _construir_motivos_elegible(
    caso: Caso,
    regla_codigo: ReglaCodigoError,
    servicio_dep: Servicio,
    srv_mod: Servicio | None,
) -> list[str]:
    """Construye la lista verificable de motivos cuando el caso sí es elegible."""
    limite = regla_codigo.limite_reprocesos or LIMITE_GENERAL_REPROCESOS
    motivos = [
        f"Estado del caso '{caso.estado}' elegible para reprocesamiento (MAN-INC v2 §4).",
        "El caso no tiene decisión final (tiene_decision_final=no).",
        f"El código de error '{caso.codigo_error}' ({regla_codigo.descripcion}) es elegible en {regla_codigo.referencia}.",
        f"El servicio dependiente '{servicio_dep.servicio_id}' se encuentra en estado 'operativo'.",
    ]
    if srv_mod is not None and srv_mod.servicio_id != servicio_dep.servicio_id:
        motivos.append(
            f"El servicio '{srv_mod.servicio_id}' requerido por E-207 se encuentra en estado 'operativo'."
        )
    motivos.append(
        f"Reprocesos previos ({caso.reprocesos_realizados}) dentro del límite permitido (< {limite})."
    )
    return motivos


def evaluar_solicitud(
    caso_id: str,
    usuario_id: str,
    repositorio: RepositorioDatos,
) -> EvaluacionResponse:
    """Evalúa autorización prioritaria por rol y elegibilidad normativa del caso."""
    # 1. Validación prioritaria simulada de rol antes de consultar casos (REQ-03).
    usuario = repositorio.obtener_usuario(usuario_id)
    if usuario is None:
        raise UsuarioNoAutorizadoError("Usuario sin autorización para evaluar reprocesamiento.")
    if usuario.rol not in ROLES_AUTORIZADOS:
        raise UsuarioNoAutorizadoError("Rol no autorizado para evaluar reprocesamiento.")

    # 2. Búsqueda de caso únicamente tras aprobar autorización (REQ-04).
    caso = repositorio.obtener_caso(caso_id)
    if caso is None:
        raise CasoNoEncontradoError("Caso no encontrado.")

    # 3. Evaluación normativa completa sin cortocircuitar para reportar todos los motivos (REQ-18).
    motivos_bloqueo: list[str] = []
    referencias: list[str] = [REF_MAN_INC]
    inconsistencia_tecnica = False
    limite_alcanzado = False
    servicio_no_operativo = False

    if caso.tiene_decision_final:
        motivos_bloqueo.append(
            "El caso ya tiene decisión final (tiene_decision_final=sí); nunca se reprocesa un caso con decisión final."
        )

    if caso.estado not in ESTADOS_ELEGIBLES:
        motivos_bloqueo.append(
            f"El estado actual del caso es '{caso.estado}'; solo se reprocesan casos en estado 'error' o 'detenido'."
        )

    regla_codigo = CATALOGO_ERRORES_V2.get(caso.codigo_error)
    if regla_codigo is None:
        inconsistencia_tecnica = True
        motivos_bloqueo.append(
            f"El código de error '{caso.codigo_error}' no existe en el catálogo vigente CAT-ERR v2."
        )
    else:
        _agregar_unico(referencias, regla_codigo.referencia)
        if not regla_codigo.reprocesable:
            motivos_bloqueo.append(
                f"El código de error '{caso.codigo_error}' ({regla_codigo.descripcion}) no es reprocesable según {regla_codigo.referencia}."
            )

    servicio_dep = repositorio.obtener_servicio(caso.servicio_dependiente)
    if servicio_dep is None:
        inconsistencia_tecnica = True
        motivos_bloqueo.append(
            f"El servicio dependiente '{caso.servicio_dependiente}' no existe en el catálogo de servicios."
        )
    elif servicio_dep.estado != "operativo":
        servicio_no_operativo = True
        motivos_bloqueo.append(
            f"El servicio dependiente '{servicio_dep.servicio_id}' se encuentra en estado '{servicio_dep.estado}' (requiere estado 'operativo')."
        )

    srv_mod: Servicio | None = None
    if caso.codigo_error == "E-207" and caso.servicio_dependiente != SERVICIO_E207:
        srv_mod = repositorio.obtener_servicio(SERVICIO_E207)
        if srv_mod is None:
            inconsistencia_tecnica = True
            motivos_bloqueo.append(
                f"El servicio '{SERVICIO_E207}' requerido por E-207 no existe en el catálogo de servicios."
            )
        elif srv_mod.estado != "operativo":
            servicio_no_operativo = True
            motivos_bloqueo.append(
                f"El servicio '{SERVICIO_E207}' requerido por E-207 se encuentra en estado '{srv_mod.estado}' (requiere estado 'operativo')."
            )

    if caso.reprocesos_realizados < 0:
        inconsistencia_tecnica = True
        motivos_bloqueo.append(
            f"El contador de reprocesos realizados ({caso.reprocesos_realizados}) es negativo e inválido."
        )
    elif caso.codigo_error == "E-512":
        if caso.reprocesos_realizados >= LIMITE_E512_REPROCESOS:
            limite_alcanzado = True
            motivos_bloqueo.append(
                f"El código 'E-512' admite un máximo específico de {LIMITE_E512_REPROCESOS} reproceso "
                f"sobre el contador global por caso (reprocesos_realizados={caso.reprocesos_realizados})."
            )
        if caso.reprocesos_realizados >= LIMITE_GENERAL_REPROCESOS:
            limite_alcanzado = True
            motivos_bloqueo.append(
                f"El caso alcanzó también el límite general de {LIMITE_GENERAL_REPROCESOS} reprocesos "
                f"({caso.reprocesos_realizados} realizados; MAN-INC v2 §4)."
            )
    elif caso.reprocesos_realizados >= LIMITE_GENERAL_REPROCESOS:
        limite_alcanzado = True
        motivos_bloqueo.append(
            f"El caso alcanzó el límite máximo general de {LIMITE_GENERAL_REPROCESOS} reprocesos "
            f"({caso.reprocesos_realizados} realizados); escalar a Ingeniería como incidente S3."
        )

    if not motivos_bloqueo:
        assert regla_codigo is not None and servicio_dep is not None and regla_codigo.accion_elegible is not None
        return EvaluacionResponse(
            puede_reprocesar=True,
            motivos=_construir_motivos_elegible(caso, regla_codigo, servicio_dep, srv_mod),
            accion_recomendada=regla_codigo.accion_elegible,
            referencias_normativas=referencias,
        )

    accion = _seleccionar_accion_bloqueada(
        caso=caso,
        regla_codigo=regla_codigo,
        inconsistencia_tecnica=inconsistencia_tecnica,
        limite_alcanzado=limite_alcanzado,
        servicio_no_operativo=servicio_no_operativo,
    )
    return EvaluacionResponse(
        puede_reprocesar=False,
        motivos=motivos_bloqueo,
        accion_recomendada=accion,
        referencias_normativas=referencias,
    )
