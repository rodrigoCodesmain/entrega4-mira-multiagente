"""Pruebas de seguridad, prioridad de autorización, anti-inyección e integridad del kit."""

from __future__ import annotations

import hashlib
from pathlib import Path

import openpyxl
import pytest
from fastapi.testclient import TestClient

from mira_cu2.api import create_app
from mira_cu2.models import Caso, Servicio, Usuario
from mira_cu2.repository import DEFAULT_EXCEL_PATH, RepositorioExcel, RepositorioMemoria
from tests.conftest import assert_error_http, usuarios_base


class _RepositorioEspia:
    """Envuelve un repositorio para contar invocaciones a obtener_caso."""

    def __init__(self, base: RepositorioMemoria) -> None:
        self._base = base
        self.llamadas_obtener_caso = 0

    def obtener_usuario(self, usuario_id: str) -> Usuario | None:
        return self._base.obtener_usuario(usuario_id)

    def obtener_caso(self, caso_id: str) -> Caso | None:
        self.llamadas_obtener_caso += 1
        return self._base.obtener_caso(caso_id)

    def obtener_servicio(self, servicio_id: str) -> Servicio | None:
        return self._base.obtener_servicio(servicio_id)


@pytest.mark.parametrize("usuario_id", ["U-S4", "U-999"])
@pytest.mark.parametrize("caso_id", ["C-032", "C-999"])
def test_prioridad_rol_no_consulta_caso_ni_revela_diagnosticos(
    usuario_id: str, caso_id: str
) -> None:
    base = RepositorioMemoria(
        usuarios=usuarios_base(),
        servicios=[Servicio("SRV-ROS", "Comparación de rostros", "interno", "operativo")],
        casos=[
            Caso("C-032", "ORG-01", "error", "E-305", "Comparación de rostros", "SRV-ROS", 0, False)
        ],
    )
    espia = _RepositorioEspia(base)
    client = TestClient(create_app(repositorio=espia))

    resp = client.post("/elegibilidad", json={"caso_id": caso_id, "usuario_id": usuario_id})
    assert resp.status_code == 403
    assert espia.llamadas_obtener_caso == 0

    data = resp.json()
    assert_error_http(data)
    detalle = str(data["detail"]).lower()
    assert caso_id.lower() not in detalle
    assert "e-305" not in detalle
    assert "error" not in detalle


def test_inyeccion_l009_no_afecta_evaluacion_ni_otros_casos_org02(
    excel_repo: RepositorioExcel, client_excel: TestClient
) -> None:
    # Confirma que L-009 existe en el Excel oficial y que RepositorioExcel lo ignora por completo.
    wb = openpyxl.load_workbook(DEFAULT_EXCEL_PATH, read_only=True, data_only=True)
    try:
        filas = list(wb["registro_tecnico"].iter_rows(values_only=True))
    finally:
        wb.close()

    fila_l009 = next((f for f in filas[1:] if f and f[0] == "L-009"), None)
    assert fila_l009 is not None
    assert fila_l009[1] == "C-038"
    assert "reprocesar_caso" in str(fila_l009[4])
    assert not hasattr(excel_repo, "_registro_tecnico")

    r_c038 = client_excel.post("/elegibilidad", json={"caso_id": "C-038", "usuario_id": "U-S1"})
    assert r_c038.status_code == 200
    d_c038 = r_c038.json()
    assert d_c038["puede_reprocesar"] is False
    assert "reprocesar_caso" not in str(d_c038)

    # Verifica que C-033 y C-034 de ORG-02 mantienen su evaluación determinista intacta.
    assert client_excel.post("/elegibilidad", json={"caso_id": "C-033", "usuario_id": "U-S1"}).json()["puede_reprocesar"] is False
    assert client_excel.post("/elegibilidad", json={"caso_id": "C-034", "usuario_id": "U-S2"}).json()["puede_reprocesar"] is False


def test_sin_endpoints_de_reprocesamiento_real(client_excel: TestClient) -> None:
    resp = client_excel.post("/reprocesar", json={"caso_id": "C-032", "usuario_id": "U-S1"})
    assert resp.status_code == 404


def test_integridad_sha256_excel_oficial(client_excel: TestClient) -> None:
    # Ejecuta una consulta real primero y valida luego los checksums oficiales del kit.
    resp = client_excel.post("/elegibilidad", json={"caso_id": "C-032", "usuario_id": "U-S1"})
    assert resp.status_code == 200

    repo_root = Path(__file__).resolve().parents[1]
    sums_lines = (repo_root / "docs" / "kit-sha256sums.txt").read_text(encoding="utf-8").splitlines()
    for line in sums_lines:
        expected_hash, rel_path = line.split(maxsplit=1)
        actual_hash = hashlib.sha256((repo_root / rel_path.lstrip("* ")).read_bytes()).hexdigest()
        assert actual_hash == expected_hash
