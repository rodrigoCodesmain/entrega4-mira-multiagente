"""Paquete de pruebas automatizadas para MIRA CU-2."""
