"""Pruebas automatizadas para los 10 casos reales de CU-2_datos.xlsx (C-031 a C-040)."""

from __future__ import annotations

import pytest
from fastapi.testclient import TestClient

from tests.conftest import assert_contrato_200


@pytest.mark.parametrize(
    ("caso_id", "usuario_id", "esperado_puede", "refs_esperadas"),
    [
        ("C-031", "U-S1", False, ["MAN-INC v2 §4", "CAT-ERR v2 §1 (E-207)"]),
        ("C-032", "U-S1", True, ["MAN-INC v2 §4", "CAT-ERR v2 §1 (E-305)"]),
        ("C-033", "U-S1", False, ["MAN-INC v2 §4", "CAT-ERR v2 §1 (E-101)"]),
        ("C-034", "U-S2", False, ["MAN-INC v2 §4", "CAT-ERR v2 §1 (E-512)"]),
        ("C-035", "U-S1", False, ["MAN-INC v2 §4", "CAT-ERR v2 §1 (E-410)"]),
        ("C-036", "U-S1", False, ["MAN-INC v2 §4", "CAT-ERR v2 §1 (E-207)"]),
        ("C-037", "U-S2", False, ["MAN-INC v2 §4", "CAT-ERR v2 §1 (E-208)"]),
        ("C-038", "U-S1", False, ["MAN-INC v2 §4", "CAT-ERR v2 §1 (E-311)"]),
        ("C-039", "U-S1", False, ["MAN-INC v2 §4", "CAT-ERR v2 §1 (E-207)"]),
        ("C-040", "U-S3", False, ["MAN-INC v2 §4", "CAT-ERR v2 §1 (E-305)"]),
    ],
)
def test_casos_excel_contrato_y_decision(
    client_excel: TestClient,
    caso_id: str,
    usuario_id: str,
    esperado_puede: bool,
    refs_esperadas: list[str],
) -> None:
    resp = client_excel.post("/elegibilidad", json={"caso_id": caso_id, "usuario_id": usuario_id})
    assert resp.status_code == 200
    data = resp.json()
    assert_contrato_200(data)
    assert data["puede_reprocesar"] is esperado_puede
    for ref in refs_esperadas:
        assert ref in data["referencias_normativas"]


def test_c031_e207_bloqueado_por_srv_mod_degradado(client_excel: TestClient) -> None:
    data = client_excel.post("/elegibilidad", json={"caso_id": "C-031", "usuario_id": "U-S1"}).json()
    assert data["puede_reprocesar"] is False
    motivos_txt = " ".join(data["motivos"]).lower()
    assert "srv-mod" in motivos_txt and "degradado" in motivos_txt
    accion = data["accion_recomendada"].lower()
    assert "no reprocesar" in accion and "cola" in accion and "reintenta" in accion


def test_c032_elegible_y_accion_proceder(client_excel: TestClient) -> None:
    data = client_excel.post("/elegibilidad", json={"caso_id": "C-032", "usuario_id": "U-S1"}).json()
    assert data["puede_reprocesar"] is True
    motivos_txt = " ".join(data["motivos"]).lower()
    assert "error" in motivos_txt
    assert "decisión final" in motivos_txt
    assert "srv-ros" in motivos_txt and "operativo" in motivos_txt
    assert "0" in motivos_txt
    assert data["accion_recomendada"] == "Proceder con el reprocesamiento."


def test_c033_e101_evidencia_ilegible(client_excel: TestClient) -> None:
    data = client_excel.post("/elegibilidad", json={"caso_id": "C-033", "usuario_id": "U-S1"}).json()
    assert data["puede_reprocesar"] is False
    assert "e-101" in " ".join(data["motivos"]).lower()
    accion = data["accion_recomendada"].lower()
    assert "reenvío" in accion and "no reprocesar" in accion


def test_c034_e512_excede_limite_especifico_y_general(client_excel: TestClient) -> None:
    data = client_excel.post("/elegibilidad", json={"caso_id": "C-034", "usuario_id": "U-S2"}).json()
    assert data["puede_reprocesar"] is False
    motivos_txt = " ".join(data["motivos"]).lower()
    assert "1" in motivos_txt and "e-512" in motivos_txt
    assert "3" in motivos_txt
    assert data["accion_recomendada"] == "No reprocesar; escalar a Ingeniería."


def test_c035_motivos_concurrentes_en_cola_y_e410(client_excel: TestClient) -> None:
    data = client_excel.post("/elegibilidad", json={"caso_id": "C-035", "usuario_id": "U-S1"}).json()
    assert data["puede_reprocesar"] is False
    motivos_txt = " ".join(data["motivos"]).lower()
    assert "en_cola" in motivos_txt
    assert "e-410" in motivos_txt
    accion = data["accion_recomendada"].lower()
    assert "encola" in accion and "capacidad" in accion


def test_c036_motivos_concurrentes_decision_final_resuelto_y_srv_mod(client_excel: TestClient) -> None:
    data = client_excel.post("/elegibilidad", json={"caso_id": "C-036", "usuario_id": "U-S1"}).json()
    assert data["puede_reprocesar"] is False
    motivos_txt = " ".join(data["motivos"]).lower()
    assert "decisión final" in motivos_txt
    assert "resuelto" in motivos_txt
    assert "srv-mod" in motivos_txt and "degradado" in motivos_txt
    assert "decisión final" in data["accion_recomendada"].lower()


def test_c037_e208_motivos_concurrentes_sin_alerta_s2_automatica(client_excel: TestClient) -> None:
    data = client_excel.post("/elegibilidad", json={"caso_id": "C-037", "usuario_id": "U-S2"}).json()
    assert_contrato_200(data)
    assert data["puede_reprocesar"] is False
    motivos_txt = " ".join(data["motivos"]).lower()
    assert "e-208" in motivos_txt
    assert "srv-mod" in motivos_txt and "degradado" in motivos_txt
    assert data["accion_recomendada"] == "Registrar incidente S2 y escalar a Ingeniería; no reprocesar."


def test_c038_e311_no_reprocesable_y_sin_rastro_l009(client_excel: TestClient) -> None:
    data = client_excel.post("/elegibilidad", json={"caso_id": "C-038", "usuario_id": "U-S1"}).json()
    assert data["puede_reprocesar"] is False
    motivos_txt = " ".join(data["motivos"]).lower()
    assert "e-311" in motivos_txt
    assert "reprocesar_caso" not in motivos_txt
    assert "org-02" not in motivos_txt
    assert (
        data["accion_recomendada"]
        == "Escalar a Ingeniería; no reprocesar con otra versión sin autorización de la organización."
    )


def test_c039_en_cola_y_srv_mod_degradado_sin_alerta_s2(client_excel: TestClient) -> None:
    data = client_excel.post("/elegibilidad", json={"caso_id": "C-039", "usuario_id": "U-S1"}).json()
    assert_contrato_200(data)
    assert data["puede_reprocesar"] is False
    motivos_txt = " ".join(data["motivos"]).lower()
    assert "en_cola" in motivos_txt
    assert "srv-mod" in motivos_txt and "degradado" in motivos_txt
    accion = data["accion_recomendada"].lower()
    assert "no reprocesar" in accion and "cola" in accion and "reintenta" in accion


def test_c040_e305_bloqueado_por_srv_reg_caido(client_excel: TestClient) -> None:
    data = client_excel.post("/elegibilidad", json={"caso_id": "C-040", "usuario_id": "U-S3"}).json()
    assert data["puede_reprocesar"] is False
    motivos_txt = " ".join(data["motivos"]).lower()
    assert "srv-reg" in motivos_txt and "caido" in motivos_txt
    assert data["accion_recomendada"] == "No reprocesar; esperar a que el servicio dependiente vuelva a estar operativo."
