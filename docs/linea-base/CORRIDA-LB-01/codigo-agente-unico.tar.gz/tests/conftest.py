"""Fixtures y utilidades compartidas para las pruebas de MIRA CU-2."""

from __future__ import annotations

from collections.abc import Iterable

import pytest
from fastapi.testclient import TestClient

from mira_cu2.api import create_app
from mira_cu2.models import Caso, Servicio, Usuario
from mira_cu2.repository import DEFAULT_EXCEL_PATH, RepositorioExcel, RepositorioMemoria

CLAVES_CONTRATO_200 = {
    "puede_reprocesar",
    "motivos",
    "accion_recomendada",
    "referencias_normativas",
}
CLAVES_PROHIBIDAS = {"alerta_s2", "severidad", "registro_tecnico"}


def usuarios_base() -> list[Usuario]:
    return [
        Usuario("U-S1", "Gabriela Núñez", "soporte_n1", "DPRIME"),
        Usuario("U-S2", "Martín Cáceres", "soporte_n2", "DPRIME"),
        Usuario("U-S3", "Valeria Ortiz", "ingenieria", "DPRIME"),
        Usuario("U-S4", "Constanza Ríos", "comercial", "DPRIME"),
    ]


def servicios_base() -> list[Servicio]:
    return [
        Servicio("SRV-MOD", "Proveedor de modelos de lenguaje y visión", "externo", "degradado"),
        Servicio("SRV-OCR", "Extracción de texto", "externo", "operativo"),
        Servicio("SRV-ROS", "Comparación de rostros", "interno", "operativo"),
        Servicio("SRV-REG", "Consulta a registros públicos", "externo", "caido"),
        Servicio("SRV-COL", "Cola de procesamiento", "interno", "operativo"),
        Servicio("SRV-API", "Interfaz de programación pública", "interno", "operativo"),
    ]


def crear_cliente_memoria(
    *,
    casos: Iterable[Caso] = (),
    servicios_override: Iterable[Servicio] = (),
    usuarios_extra: Iterable[Usuario] = (),
) -> TestClient:
    """Crea un TestClient aislado con datos sintéticos en memoria."""
    servicios = {s.servicio_id: s for s in servicios_base()}
    for servicio in servicios_override:
        servicios[servicio.servicio_id] = servicio

    usuarios = {u.usuario_id: u for u in usuarios_base()}
    for usuario in usuarios_extra:
        usuarios[usuario.usuario_id] = usuario

    repo = RepositorioMemoria(
        usuarios=usuarios.values(),
        servicios=servicios.values(),
        casos=list(casos),
    )
    return TestClient(create_app(repositorio=repo))


def assert_contrato_200(data: dict) -> None:
    """Valida exactamente el contrato de 4 campos de HTTP 200 OK y exclusiones."""
    assert set(data.keys()) == CLAVES_CONTRATO_200
    assert CLAVES_PROHIBIDAS.isdisjoint(data.keys())
    assert isinstance(data["puede_reprocesar"], bool)
    assert isinstance(data["motivos"], list) and len(data["motivos"]) >= 1
    assert all(isinstance(m, str) and m.strip() != "" for m in data["motivos"])
    assert isinstance(data["accion_recomendada"], str) and data["accion_recomendada"].strip() != ""
    assert isinstance(data["referencias_normativas"], list) and len(data["referencias_normativas"]) >= 1
    assert all(isinstance(r, str) and r.strip() != "" for r in data["referencias_normativas"])

    texto_completo = " ".join(
        [*data["motivos"], data["accion_recomendada"], *data["referencias_normativas"]]
    ).lower()
    assert "cat-err v1" not in texto_completo
    assert "v1_derogado" not in texto_completo


def assert_error_http(data: dict) -> None:
    """Valida que una respuesta HTTP 403/404/422 sea error estándar sin contrato de evaluación."""
    assert "detail" in data
    assert CLAVES_CONTRATO_200.isdisjoint(data.keys())


@pytest.fixture(scope="session")
def excel_repo() -> RepositorioExcel:
    return RepositorioExcel(DEFAULT_EXCEL_PATH)


@pytest.fixture(scope="session")
def client_excel(excel_repo: RepositorioExcel) -> TestClient:
    return TestClient(create_app(repositorio=excel_repo))
